function varargout = drumMachine(varargin)
% DRUMMACHINE MATLAB code for drumMachine.fig
%      DRUMMACHINE, by itself, creates a new DRUMMACHINE or raises the existing
%      singleton*.
%
%      H = DRUMMACHINE returns the handle to a new DRUMMACHINE or the handle to
%      the existing singleton*.
%
%      DRUMMACHINE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DRUMMACHINE.M with the given input arguments.
%
%      DRUMMACHINE('Property','Value',...) creates a new DRUMMACHINE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before drumMachine_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      playr.  All inputs are passed to drumMachine_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help drumMachine

% Last Modified by GUIDE v2.5 13-Apr-2017 12:02:56

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @drumMachine_OpeningFcn, ...
                   'gui_OutputFcn',  @drumMachine_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before drumMachine is made visible.
function drumMachine_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to drumMachine (see VARARGIN)

% Choose default command line output for drumMachine
handles.output = hObject;

[handles.cs1, handles.fc1] = audioread('drummachinesounds\345[kb]120_electrobreaker.wav.mp3');
[handles.cs2, handles.fc2] = audioread('drummachinesounds\63[kb]164_classical-piano-loop.aif.mp3');
[handles.cs3, handles.fc3] = audioread('drummachinesounds\223[kb]188_wokky-guitar.wav.mp3');
[handles.cs4, handles.fc4] = audioread('drummachinesounds\334[kb]124_bob-james_far-and-ole.wav.mp3');
[handles.cs5, handles.fc5] = audioread('drummachinesounds\408[kb]epiano-two-chords.wav.mp3');
[handles.cs6, handles.fc6] = audioread('drummachinesounds\134[kb]077_mello-rock-organ.wav.mp3');
[handles.cs7, handles.fc7] = audioread('drummachinesounds\1004[kb]124_deep-cymbal-hello.wav.mp3');
[handles.cs8, handles.fc8] = audioread('drummachinesounds\837[kb]099_moody-hip-hop-piano.wav.mp3');
[handles.cs9, handles.fc9] = audioread('drummachinesounds\689[kb]120_fun-echo-guitar-loop.wav.mp3');
[handles.cs10, handles.fc10] = audioread('drummachinesounds\993[kb]125_bitcrushed-minimal.wav.mp3');
[handles.cs11, handles.fc11] = audioread('drummachinesounds\861[kb]096_salsa-piano-1.wav.mp3');
[handles.cs12, handles.fc12] = audioread('drummachinesounds\229[kb]180_chilla-guitar-chops.wav.mp3');
[handles.cs13, handles.fc13] = audioread('drummachinesounds\1708[kb]079_noisy-vinyl-loop.wav.mp3');
[handles.cs14, handles.fc14] = audioread('drummachinesounds\829[kb]christmas_rhodes.aif.mp3');
[handles.cs15, handles.fc15] = audioread('drummachinesounds\501[kb]165_milky-crunchy-dubby-chords.wav.mp3');
[handles.cs16, handles.fc16] = audioread('drummachinesounds\1337[kb]124_newtech-deep-kick.wav.mp3');
[handles.cs17, handles.fc17] = audioread('drummachinesounds\1272[kb]130_electric-piano-A.wav.mp3');
[handles.cs18, handles.fc18] = audioread('drummachinesounds\320[kb]130_twangy-rock-or-country-guitar.wav.mp3');
[handles.cs19, handles.fc19] = audioread('drummachinesounds\1984[kb]085_dumping-swing-crunch.wav.mp3');
[handles.cs20, handles.fc20] = audioread('drummachinesounds\1722[kb]096_minor-piano-melody.wav.mp3');
[handles.cs21, handles.fc21] = audioread('drummachinesounds\515[kb]080_country-boy-slide-guitar.wav.mp3');
global flag;
flag = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
global au;
au=audiorecorder;
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes drumMachine wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = drumMachine_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in r1.
function r1_Callback(hObject, eventdata, handles)
% hObject    handle to r1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in r2.
function r2_Callback(hObject, eventdata, handles)
% hObject    handle to r2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in r3.
function r3_Callback(hObject, eventdata, handles)
% hObject    handle to r3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in c1.
function c1_Callback(hObject, eventdata, handles)
% hObject    handle to c1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c1,'backgroundcolor','[0 1 1]');




% --- Executes on button press in c2.
function c2_Callback(hObject, eventdata, handles)
% hObject    handle to c2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c2,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c3.
function c3_Callback(hObject, eventdata, handles)
% hObject    handle to c3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c3,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c4.
function c4_Callback(hObject, eventdata, handles)
% hObject    handle to c4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c4,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c5.
function c5_Callback(hObject, eventdata, handles)
% hObject    handle to c5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c5,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c6.
function c6_Callback(hObject, eventdata, handles)
% hObject    handle to c6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c6,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c7.
function c7_Callback(hObject, eventdata, handles)
% hObject    handle to c7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c7,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c8.
function c8_Callback(hObject, eventdata, handles)
% hObject    handle to c8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c8,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c9.
function c9_Callback(hObject, eventdata, handles)
% hObject    handle to c9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c9,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c10.
function c10_Callback(hObject, eventdata, handles)
% hObject    handle to c10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c10,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c11.
function c11_Callback(hObject, eventdata, handles)
% hObject    handle to c11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0];
set(handles.c11,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c12.
function c12_Callback(hObject, eventdata, handles)
% hObject    handle to c12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0];
set(handles.c12,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c13.
function c13_Callback(hObject, eventdata, handles)
% hObject    handle to c13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0];
set(handles.c13,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c14.
function c14_Callback(hObject, eventdata, handles)
% hObject    handle to c14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0];
set(handles.c14,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c15.
function c15_Callback(hObject, eventdata, handles)
% hObject    handle to c15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0];
set(handles.c15,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c16.
function c16_Callback(hObject, eventdata, handles)
% hObject    handle to c16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0];
set(handles.c16,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c17.
function c17_Callback(hObject, eventdata, handles)
% hObject    handle to c17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0];
set(handles.c17,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c18.
function c18_Callback(hObject, eventdata, handles)
% hObject    handle to c18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0];
set(handles.c18,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c19.
function c19_Callback(hObject, eventdata, handles)
% hObject    handle to c19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0];
set(handles.c19,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c20.
function c20_Callback(hObject, eventdata, handles)
% hObject    handle to c20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0];
set(handles.c20,'backgroundcolor','[0 1 1]');


% --- Executes on button press in c21.
function c21_Callback(hObject, eventdata, handles)
% hObject    handle to c21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
flag = flag + [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1];
set(handles.c21,'backgroundcolor','[0 1 1]');


% --- Executes on button press in record.
function record_Callback(hObject, eventdata, handles)
% hObject    handle to record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au;
record(au);
global flag;
dflag=[0 0 0 0 0 0 0];
if flag(1)==1
    dflag(1)=1;
    sound(handles.cs1(1:handles.fc1*2),handles.fc1);
end
if flag(2)==1
    dflag(1)=1;
    sound([handles.cs2(1:handles.fc2*1);handles.cs2(1:handles.fc2*1)],handles.fc2);
end
if flag(3)==1
    dflag(1)=1;
    sound([handles.cs3(1:handles.fc3*1); handles.cs3(1:handles.fc3*1)],handles.fc3);
    
end
if dflag(1)==1
    pause(2);
end
if flag(4)==1
    dflag(2)=1;
    sound(handles.cs4(1:handles.fc4*2),handles.fc4);
end
if flag(5)==1
    dflag(2)=1;
    sound(handles.cs5(1:handles.fc5*2),handles.fc5);
end
if flag(6)==1
    dflag(2)=1;
    sound(handles.cs6(1:handles.fc6*2),handles.fc6);
end
if dflag(2)==1
    pause(2);
end
if flag(7)==1
    dflag(3)=1;
    sound(handles.cs7(1:handles.fc7*3),handles.fc7);
end
if flag(8)==1
    dflag(3)=1;
    sound(handles.cs8(1:handles.fc8*3),handles.fc8);
end
if flag(9)==1
    dflag(3)=1;
    sound(handles.cs9(1:handles.fc9*3),handles.fc9);
end
if dflag(3)==1
    pause(3);
end
if flag(10)==1
    dflag(4)=1;
    sound(handles.cs10(1:handles.fc10*3),handles.fc10);
end
if flag(11)==1
    dflag(4)=1;
    sound(handles.cs11(1:handles.fc11*3),handles.fc11);
end
if flag(12)==1
    dflag(4)=1;
    sound([handles.cs12(1:handles.fc12*0.5); handles.cs12(1:handles.fc12*2.5)],handles.fc12);
end
if dflag(4)==1
    pause(3);
end
if flag(13)==1
    dflag(5)=1;
    sound(handles.cs13(1:handles.fc13*4),handles.fc13);
end
if flag(14)==1
    dflag(5)=1;
    sound(handles.cs14(1:handles.fc14*4),handles.fc14);
end
if flag(15)==1
    dflag(5)=1;
    sound(handles.cs15(1:handles.fc15*4),handles.fc15);
end
if dflag(5)==1
    pause(4);
end
if flag(16)==1
    dflag(6)=1;
    sound(handles.cs16(1:handles.fc16*5),handles.fc16);
end
if flag(17)==1
    dflag(6)=1;
    sound(handles.cs17(1:handles.fc17*5),handles.fc17);
end
if flag(18)==1
    dflag(6)=1;
    sound([handles.cs18(1:handles.fc18*2); handles.cs18(1:handles.fc18*3)],handles.fc18);
end
if dflag(6)==1
    pause(5);
end
if flag(19)==1
    dflag(7)=1;
    sound(handles.cs19(1:handles.fc19*6),handles.fc19);
end
if flag(20)==1
    dflag(7)=1;
    sound(handles.cs20(1:handles.fc20*6),handles.fc20);
end
if flag(21)==1
    dflag(7)=1;
    sound(handles.cs21(1:handles.fc21*6),handles.fc21);
end
if dflag(7)==1
    pause(6);
end
stop(au);
p=getaudiodata(au);
plot(handles.audio,p);



% --- Executes on button press in playr.
function playr_Callback(hObject, eventdata, handles)
% hObject    handle to playr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au;
p=getaudiodata(au);
plot(handles.audio,p);
sound(p);


% --- Executes on button press in play.
function play_Callback(hObject, eventdata, handles)
% hObject    handle to play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
dflag=[0 0 0 0 0 0 0];
if flag(1)==1
    dflag(1)=1;
    sound(handles.cs1(1:handles.fc1*2),handles.fc1);
end
if flag(2)==1
    dflag(1)=1;
    sound([handles.cs2(1:handles.fc2*1);handles.cs2(1:handles.fc2*1)],handles.fc2);
end
if flag(3)==1
    dflag(1)=1;
    sound([handles.cs3(1:handles.fc3*1); handles.cs3(1:handles.fc3*1)],handles.fc3);
    
end
if dflag(1)==1
    pause(2);
end
if flag(4)==1
    dflag(2)=1;
    sound(handles.cs4(1:handles.fc4*2),handles.fc4);
end
if flag(5)==1
    dflag(2)=1;
    sound(handles.cs5(1:handles.fc5*2),handles.fc5);
end
if flag(6)==1
    dflag(2)=1;
    sound(handles.cs6(1:handles.fc6*2),handles.fc6);
end
if dflag(2)==1
    pause(2);
end
if flag(7)==1
    dflag(3)=1;
    sound(handles.cs7(1:handles.fc7*3),handles.fc7);
end
if flag(8)==1
    dflag(3)=1;
    sound(handles.cs8(1:handles.fc8*3),handles.fc8);
end
if flag(9)==1
    dflag(3)=1;
    sound(handles.cs9(1:handles.fc9*3),handles.fc9);
end
if dflag(3)==1
    pause(3);
end
if flag(10)==1
    dflag(4)=1;
    sound(handles.cs10(1:handles.fc10*3),handles.fc10);
end
if flag(11)==1
    dflag(4)=1;
    sound(handles.cs11(1:handles.fc11*3),handles.fc11);
end
if flag(12)==1
    dflag(4)=1;
    sound([handles.cs12(1:handles.fc12*0.5); handles.cs12(1:handles.fc12*2.5)],handles.fc12);
end
if dflag(4)==1
    pause(3);
end
if flag(13)==1
    dflag(5)=1;
    sound(handles.cs13(1:handles.fc13*4),handles.fc13);
end
if flag(14)==1
    dflag(5)=1;
    sound(handles.cs14(1:handles.fc14*4),handles.fc14);
end
if flag(15)==1
    dflag(5)=1;
    sound(handles.cs15(1:handles.fc15*4),handles.fc15);
end
if dflag(5)==1
    pause(4);
end
if flag(16)==1
    dflag(6)=1;
    sound(handles.cs16(1:handles.fc16*5),handles.fc16);
end
if flag(17)==1
    dflag(6)=1;
    sound(handles.cs17(1:handles.fc17*5),handles.fc17);
end
if flag(18)==1
    dflag(6)=1;
    sound([handles.cs18(1:handles.fc18*2); handles.cs18(1:handles.fc18*3)],handles.fc18);
end
if dflag(6)==1
    pause(5);
end
if flag(19)==1
    dflag(7)=1;
    sound(handles.cs19(1:handles.fc19*6),handles.fc19);
end
if flag(20)==1
    dflag(7)=1;
    sound(handles.cs20(1:handles.fc20*6),handles.fc20);
end
if flag(21)==1
    dflag(7)=1;
    sound(handles.cs21(1:handles.fc21*6),handles.fc21);
end
if dflag(7)==1
    pause(6);
end
cla;


% --- Executes on button press in clear.
function clear_Callback(hObject, eventdata, handles)
% hObject    handle to clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global flag;
global au;
flag=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
set(handles.c1,'backgroundcolor','[1 0.95 0.87]');
set(handles.c2,'backgroundcolor','[1 0.95 0.87]');
set(handles.c3,'backgroundcolor','[1 0.95 0.87]');
set(handles.c4,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c5,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c6,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c7,'backgroundcolor','[1 0.95 0.87]');
set(handles.c8,'backgroundcolor','[1 0.95 0.87]');
set(handles.c9,'backgroundcolor','[1 0.95 0.87]');
set(handles.c10,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c11,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c12,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c13,'backgroundcolor','[1 0.95 0.87]');
set(handles.c14,'backgroundcolor','[1 0.95 0.87]');
set(handles.c15,'backgroundcolor','[1 0.95 0.87]');
set(handles.c16,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c17,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c18,'backgroundcolor','[0.871 0.922 0.98]');
set(handles.c19,'backgroundcolor','[1 0.95 0.87]');
set(handles.c20,'backgroundcolor','[1 0.95 0.87]');
set(handles.c21,'backgroundcolor','[1 0.95 0.87]');
cla;
